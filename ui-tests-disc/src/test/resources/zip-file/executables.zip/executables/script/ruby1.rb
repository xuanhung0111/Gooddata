#Referrence: https://confluence.gooddata.com/confluence/display/analysis/CloverETL+Transformation+Deployment#CloverETLTransformationDeployment-QAConsiderations
require 'rubygems'
require 'rest_client'
require 'json'
require 'yaml'
require File.expand_path('../../lib/basic', __FILE__)

def upload_zip(url, file)
  run(true){
	response = RestClient::Request.execute(
        :method => :put,
        :url => url + File.basename(file),
        :user => @username,
        :password => @password,
        :timeout => @timeout,
        :headers => {
          :user_agent => @gem_version_string,
          :content_type => 'application/zip',
		  :disposition => 'attachment',
		  :filename => file.to_s
        },
        :payload => File.open(file, "rb+").read
      )
	  
	  response
	}
end

def validate_param (config)
	result = 0;
	if (config['server'].nil?) || (config['server'].empty?) 
		result = result + 1
		puts 'server is empty. Please checking config.yaml again!'
	end
	if (config['webdav'].nil?) || (config['webdav'].empty?) 
		result = result + 1
		puts 'webdav is empty. Please checking config.yaml again!'
	end
	if (config['username'].nil?) || (config['username'].empty?) 
		result = result + 1
		puts 'username is empty. Please checking config.yaml again!'
	end
	if (config['password'].nil?) 
		result = result + 1
		puts 'password is empty. Please checking config.yaml again!'
	end
	if (config['projectId'].nil?) || (config['projectId'].empty?) 
		result = result + 1
		puts 'projectId is empty. Please checking config.yaml again!'
	end
	if (config['processName'].nil?) || (config['processName'].empty?) 
		result = result + 1
		puts 'processName is empty. Please checking config.yaml again!'
	end
	if (config['graphName'].nil?) || (config['graphName'].empty?) 
		result = result + 1
		puts 'graphName is empty. Please checking config.yaml again!'
	end	
	
	result
end

def init
	serverLink = File.expand_path('../config.yaml', __FILE__)
	begin
	  config = YAML::load( File.open( serverLink ) )
	rescue Exception => e
	  puts e.inspect
	  Process.exit
	end

	if validate_param(config) == 0 then
		@serverbase = config['server']
		@webdav = config['webdav']
		@username = config['username']
		@password = config['password']
		@testproject = config['projectId']
		@processName = config['processName']
		@graphName = config['graphName']
		@timeout = config['timeout']
		@gem_version_string = config['gem_version_string']
		@cookies = '' 
	else
		Process.exit
	end
	
	puts "Running against " + @serverbase
	puts "Using username " + @username
	login
	
	response = upload_zip(@webdav+"/uploads/", "data/graph-test.zip")
	if response.nil? then
		puts 'graph-test.zip was uploaded.'
	end
end

def create_process
	data = "{\"process\":{\"name\":\""+@processName+"\", \"path\":\"/uploads/graph-test.zip\"}}"
	response = run(true) { RestClient.post @serverbase + '/gdc/projects/' + @testproject + '/dataload/processes', data, :cookies => @cookies, :content_type => :json,:accept => 'json'}
	puts response.body
	response = JSON.parse(response.body)
	
	response
end

def invoke_process (executionsLink)
	data = "{\"execution\":{\"graph\":\"marketing-graph/graph/"+@graphName+".grf\"}}"
	response = run(true) { RestClient.post @serverbase + executionsLink, data,:cookies => @cookies,:content_type => :json,:accept => :json }
	puts ""
	puts response.body
	response = JSON.parse(response.body)
	
	response
end

def poll_response (pollLink)
	begin
		response = run(true) { RestClient.get @serverbase + pollLink, :cookies => @cookies, :accept => 'json' }
		puts "Response code: " + response.code.to_s
		puts response.headers[:x_gdc_request]
	end while response.code !=204

	puts 'Process is successful. See log file at ' + pollLink + '/log'
end		



#Execute
init
puts ""
puts '3. Create process'
response = create_process
if response["process"]["links"] != nil then
	puts ""
	puts '4. Users invokes the process'
	response = invoke_process(response["process"]["links"]["executions"])
	if response["executionTask"]["links"]["poll"] != nil then
		puts ""
		puts '5.Poll for the response '
		poll_response(response["executionTask"]["links"]["poll"])
	end	
end



