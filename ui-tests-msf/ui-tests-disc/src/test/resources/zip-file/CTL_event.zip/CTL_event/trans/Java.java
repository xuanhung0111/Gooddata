import org.jetel.component.DataRecordTransform;
import org.jetel.data.DataRecord;
import org.jetel.exception.TransformException;


public class Java extends DataRecordTransform {

	@Override
	public int transform(DataRecord[] arg0, DataRecord[] arg1)
			throws TransformException {
		// TODO Auto-generated method stub
		System.out.println("MaliciousClass loaded!"); 
		return 0;
	}

}
